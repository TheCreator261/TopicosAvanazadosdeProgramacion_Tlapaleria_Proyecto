from flask import Flask, render_template, request, redirect, url_for, flash
import mysql.connector
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'clave_secreta'  # Cambia esto en producción

# Configuración de la base de datos
def get_db_connection():
    try:
        connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password="26noviembre2005",
            database="tlapaleria"
        )
        return connection
    except mysql.connector.Error as err:
        print(f"Error de conexión a la base de datos: {err}")
        flash("Error al conectar con la base de datos", 'error')
        return None 

@app.route('/')
def index():
    return redirect(url_for('inventario'))

@app.route('/inventario', methods=['GET', 'POST'])
def inventario():
    connection = get_db_connection()
    if not connection:
        return render_template('inventario.html', productos=[], estatus=[], categorias=[], inventario=[])
    
    try:
        cursor = connection.cursor(dictionary=True)
        
        # Obtener datos para los datalists
        cursor.execute('SELECT * FROM producto')
        productos = cursor.fetchall()
        
        cursor.execute('SELECT * FROM estatus')
        estatus = cursor.fetchall()
        
        cursor.execute('SELECT * FROM categoria')
        categorias = cursor.fetchall()
        
        # Procesar formulario de agregar
        if request.method == 'POST':
            producto_nombre = request.form.get('producto')
            cantidad = request.form.get('cantidad')
            fecha = request.form.get('fecha')
            estatus_motivo = request.form.get('estatus')
            categoria_nombre = request.form.get('categoria')
            
            if not all([producto_nombre, cantidad, fecha, estatus_motivo, categoria_nombre]):
                flash('Todos los campos son requeridos', 'error')
            else:
                try:
                    # Obtener IDs basados en los nombres ingresados
                    cursor.execute('SELECT ID_Producto FROM producto WHERE Nombre = %s', (producto_nombre,))
                    producto = cursor.fetchone()
                    if not producto:
                        flash('Producto no encontrado', 'error')
                        return redirect(url_for('inventario'))
                    
                    cursor.execute('SELECT ID_estatus FROM estatus WHERE Motivo = %s', (estatus_motivo,))
                    estado = cursor.fetchone()
                    if not estado:
                        flash('Estatus no encontrado', 'error')
                        return redirect(url_for('inventario'))
                    
                    cursor.execute('SELECT ID_Categoria FROM categoria WHERE Nombre_Categoria = %s', (categoria_nombre,))
                    categoria = cursor.fetchone()
                    if not categoria:
                        flash('Categoría no encontrada', 'error')
                        return redirect(url_for('inventario'))
                    
                    # Insertar el registro
                    cursor.execute('''
                        INSERT INTO inventario (ID_Producto, Cantidad, Fecha, ID_estatus, ID_Categoria)
                        VALUES (%s, %s, %s, %s, %s)
                    ''', (producto['ID_Producto'], cantidad, fecha, estado['ID_estatus'], categoria['ID_Categoria']))
                    connection.commit()
                    flash('Registro de inventario agregado correctamente', 'success')
                except mysql.connector.Error as err:
                    connection.rollback()
                    flash(f'Error al agregar registro: {err}', 'error')
        
        # Obtener registros de inventario
        cursor.execute('''
            SELECT i.*, p.Nombre AS producto_nombre, 
                   e.Motivo AS estatus_nombre, 
                   c.Nombre_Categoria AS categoria_nombre,
                   DATE_FORMAT(i.Fecha, '%%d/%%m/%%Y') AS fecha_formateada
            FROM inventario i
            JOIN producto p ON i.ID_Producto = p.ID_Producto
            JOIN estatus e ON i.ID_estatus = e.ID_estatus
            JOIN categoria c ON i.ID_Categoria = c.ID_Categoria
            ORDER BY i.Fecha DESC
        ''')
        inventario = cursor.fetchall()
        
        return render_template('inventario.html', 
                            productos=productos,
                            estatus=estatus,
                            categorias=categorias,
                            inventario=inventario)
        
    except Exception as e:
        print(f"Error en inventario: {e}")
        flash('Ocurrió un error al cargar el inventario', 'error')
        return render_template('inventario.html', productos=[], estatus=[], categorias=[], inventario=[])
    finally:
        if 'cursor' in locals():
            cursor.close()
        if connection.is_connected():
            connection.close()

@app.route('/estatus', methods=['GET', 'POST'])
def gestion_estatus():
    connection = get_db_connection()
    if not connection:
        return render_template('estatus.html', estatus=[])
    
    try:
        cursor = connection.cursor(dictionary=True)
        
        if request.method == 'POST':
            motivo = request.form.get('motivo', '').strip()
            if not motivo:
                flash('El motivo no puede estar vacío', 'error')
            else:
                try:
                    cursor.execute('INSERT INTO estatus (Motivo) VALUES (%s)', (motivo,))
                    connection.commit()
                    flash('Estatus agregado correctamente', 'success')
                except mysql.connector.Error as err:
                    connection.rollback()
                    flash(f'Error al agregar estatus: {err}', 'error')
        
        cursor.execute('SELECT * FROM estatus ORDER BY Motivo')
        estatus = cursor.fetchall()
        
        return render_template('estatus.html', estatus=estatus)
        
    except Exception as e:
        print(f"Error en gestión de estatus: {e}")
        flash('Ocurrió un error al cargar los estatus', 'error')
        return render_template('estatus.html', estatus=[])
    finally:
        if 'cursor' in locals():
            cursor.close()
        if connection.is_connected():
            connection.close()

@app.route('/categorias', methods=['GET', 'POST'])
def gestion_categorias():
    connection = get_db_connection()
    if not connection:
        return render_template('categorias.html', categorias=[])
    
    try:
        cursor = connection.cursor(dictionary=True)
        
        if request.method == 'POST':
            nombre = request.form.get('nombre', '').strip()
            if not nombre:
                flash('El nombre no puede estar vacío', 'error')
            else:
                try:
                    cursor.execute('INSERT INTO categoria (Nombre_Categoria) VALUES (%s)', (nombre,))
                    connection.commit()
                    flash('Categoría agregada correctamente', 'success')
                except mysql.connector.Error as err:
                    connection.rollback()
                    flash(f'Error al agregar categoría: {err}', 'error')
        
        cursor.execute('SELECT * FROM categoria ORDER BY Nombre_Categoria')
        categorias = cursor.fetchall()
        
        return render_template('categorias.html', categorias=categorias)
        
    except Exception as e:
        print(f"Error en gestión de categorías: {e}")
        flash('Ocurrió un error al cargar las categorías', 'error')
        return render_template('categorias.html', categorias=[])
    finally:
        if 'cursor' in locals():
            cursor.close()
        if connection.is_connected():
            connection.close()

@app.route('/agregar_producto', methods=['GET', 'POST'])
def agregar_producto():
    connection = get_db_connection()
    if not connection:
        return render_template('agregar_producto.html', categorias=[])
    
    try:
        cursor = connection.cursor(dictionary=True)
        
        cursor.execute('SELECT * FROM categoria')
        categorias = cursor.fetchall()
        
        if request.method == 'POST':
            nombre = request.form.get('nombre', '').strip()
            descripcion = request.form.get('descripcion', '').strip()
            precio = request.form.get('precio', '0')
            stock = request.form.get('stock', '0')
            categoria_id = request.form.get('categoria', '')
            
            if not all([nombre, descripcion, categoria_id]):
                flash('Todos los campos son requeridos', 'error')
            else:
                try:
                    precio = float(precio)
                    stock = int(stock)
                    if precio <= 0 or stock < 0:
                        flash('Precio y stock deben ser valores positivos', 'error')
                    else:
                        cursor.execute('''
                            INSERT INTO producto (Nombre, Descripcion, Precio, Stock, ID_Categoria)
                            VALUES (%s, %s, %s, %s, %s)
                        ''', (nombre, descripcion, precio, stock, categoria_id))
                        connection.commit()
                        flash('Producto agregado correctamente', 'success')
                        return redirect(url_for('inventario'))
                except ValueError:
                    flash('Precio y stock deben ser números válidos', 'error')
                except mysql.connector.Error as err:
                    connection.rollback()
                    flash(f'Error al agregar producto: {err}', 'error')
        
        return render_template('agregar_producto.html', categorias=categorias)
        
    except Exception as e:
        print(f"Error en agregar producto: {e}")
        flash('Ocurrió un error al cargar el formulario', 'error')
        return render_template('agregar_producto.html', categorias=[])
    finally:
        if 'cursor' in locals():
            cursor.close()
        if connection.is_connected():
            connection.close()

if __name__ == '__main__':
    app.run(debug=True)