from flask import Flask, render_template, request, redirect, url_for, flash
import mysql.connector
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'clave_secreta'

# Conexión a la base de datos
def get_db_connection():
    try:
        return mysql.connector.connect(
            host="localhost",
            user="root",
            password="Gears297005",
            database="tlapaleria"
        )
    except mysql.connector.Error as err:
        print(f"Error de conexión: {err}")
        return None

@app.route('/')
def index():
    return redirect(url_for('inventario'))

# --------------------- INVENTARIO ---------------------
@app.route('/inventario', methods=['GET', 'POST'])
def inventario():
    connection = get_db_connection()
    if not connection:
        return render_template('inventario.html', productos=[], categorias=[], inventario=[])

    try:
        cursor = connection.cursor(dictionary=True)

        # Obtener todas las categorías
        cursor.execute('SELECT * FROM categoria ORDER BY nombre_categoria')
        categorias = cursor.fetchall()

        # Obtener todos los productos
        cursor.execute('SELECT * FROM producto ORDER BY nombre')  
        productos = cursor.fetchall()

        # Manejar la lógica de agregar producto al inventario
        if request.method == 'POST':
            categoria_id = request.form.get('categoria')
            producto_id = request.form.get('producto')
            nombre = request.form.get('producto')
            cantidad = request.form.get('cantidad')
            fecha = request.form.get('fecha')
            nombre_categoria = request.form.get('categoria')

            if not all([nombre, cantidad, fecha, nombre_categoria]):
                flash('Todos los campos son requeridos', 'error')
            else:
                try:
                    # Buscar producto por id_producto
                    cursor.execute('SELECT id_producto FROM producto WHERE id_producto = %s', (producto_id,))
                    producto = cursor.fetchone()
                    if not producto:
                       flash('Producto no encontrado', 'error')
                       return redirect(url_for('inventario'))

                    cursor.execute('SELECT id_categoria FROM categoria WHERE id_categoria = %s', (categoria_id,))
                    categoria = cursor.fetchone()
                    if not categoria:
                       flash('Categoría no encontrada', 'error')
                       return redirect(url_for('inventario'))

                    cursor.execute(''' 
                        INSERT INTO inventario (id_producto, cantidad, fecha, id_categoria)  # Cambié 'ID_Producto' por 'id_producto' y 'ID_Categoria' por 'id_categoria'
                        VALUES (%s, %s, %s, %s)
                    ''', (producto['id_producto'], cantidad, fecha, categoria['id_categoria']))
                    connection.commit()
                    flash('Registro de inventario agregado correctamente', 'success')
                except mysql.connector.Error as err:
                    connection.rollback()
                    flash(f'Error al agregar registro: {err}', 'error')

        # Obtener los registros de inventario
        cursor.execute(''' 
            SELECT i.*, p.nombre AS producto_nombre, 
                   c.nombre_categoria AS categoria_nombre,  
                   DATE_FORMAT(i.fecha, '%%d/%%m/%%Y') AS fecha_formateada  
            FROM inventario i
            JOIN producto p ON i.id_producto = p.id_producto  
            JOIN categoria c ON i.id_categoria = c.id_categoria  
            ORDER BY i.fecha DESC  
        ''')

        inventario = cursor.fetchall()

        return render_template('inventario.html', 
                               productos=productos, 
                               categorias=categorias,
                               inventario=inventario)

    except Exception as e:
        print(f"Error en inventario: {e}")
        flash('Ocurrió un error al cargar el inventario', 'error')
        return render_template('inventario.html', productos=[], categorias=[], inventario=[])
    finally:
        if 'cursor' in locals():
            cursor.close()
        if connection.is_connected():
            connection.close()

# --------------------- ESTATUS ---------------------
@app.route('/estatus', methods=['GET', 'POST'])
def gestion_estatus():
    connection = get_db_connection()
    if not connection:
        flash('Error de conexión con la base de datos', 'error')
        return render_template('estatus.html', estatus=[])

    try:
        cursor = connection.cursor(dictionary=True)

        if request.method == 'POST':
            motivo = request.form.get('motivo', '').strip()
            if motivo:
                cursor.execute('INSERT INTO estatus (Motivo) VALUES (%s)', (motivo,))
                connection.commit()
                flash('Estatus agregado correctamente', 'success')
            else:
                flash('El motivo no puede estar vacío', 'error')

        cursor.execute('SELECT * FROM estatus ORDER BY Motivo')
        estatus = cursor.fetchall()

        return render_template('estatus.html', estatus=estatus)

    except Exception as e:
        print(f"Error en gestión de estatus: {e}")
        flash('Ocurrió un error al cargar los estatus', 'error')
        return render_template('estatus.html', estatus=[])
    finally:
        cursor.close()
        connection.close()

# --------------------- CATEGORÍAS ---------------------
@app.route('/categorias', methods=['GET', 'POST'])
def gestion_categorias():
    connection = get_db_connection()
    if not connection:
        return render_template('categorias.html', categorias=[])

    try:
        cursor = connection.cursor(dictionary=True)

        if request.method == 'POST':
            nombre = request.form.get('nombre', '').strip()
            if not nombre:
                flash('El nombre no puede estar vacío', 'error')
            else:
                try:
                    cursor.execute('INSERT INTO categoria (nombre_categoria) VALUES (%s)', (nombre,))  
                    connection.commit()
                    flash('Categoría agregada correctamente', 'success')
                except mysql.connector.Error as err:
                    connection.rollback()
                    flash(f'Error al agregar categoría: {err}', 'error')

        # Obtener todas las categorías de la base de datos
        cursor.execute('SELECT * FROM categoria ORDER BY nombre_categoria')  
        categorias = cursor.fetchall()

        return render_template('categorias.html', categorias=categorias)

    except Exception as e:
        print(f"Error en gestión de categorías: {e}")
        flash('Ocurrió un error al cargar las categorías', 'error')
        return render_template('categorias.html', categorias=[])
    finally:
        if 'cursor' in locals():
            cursor.close()
        if connection.is_connected():
            connection.close()

# --------------------- AGREGAR PRODUCTO ---------------------
@app.route('/agregar_producto', methods=['GET', 'POST'])
def agregar_producto():
    connection = get_db_connection()
    if not connection:
        return render_template('agregar_producto.html', categorias=[])

    try:
        cursor = connection.cursor(dictionary=True)

        # Consultar las categorías de la base de datos
        cursor.execute('SELECT * FROM categoria ORDER BY nombre_categoria')  # Cambiar a minúsculas
        categorias = cursor.fetchall()

        if request.method == 'POST':
            nombre = request.form.get('nombre', '').strip()
            descripcion = request.form.get('descripcion', '').strip()
            precio = request.form.get('precio', '0')
            stock = request.form.get('stock', '0')
            categoria_id = request.form.get('categoria', '')

            if not all([nombre, descripcion, categoria_id]):
                flash('Todos los campos son requeridos', 'error')
            else:
                try:
                    precio = float(precio)
                    stock = int(stock)
                    if precio <= 0 or stock < 0:
                        flash('Precio y stock deben ser valores positivos', 'error')
                    else:
                        cursor.execute('''
                            INSERT INTO producto (nombre, descripcion, precio, stock, id_categoria)  
                            VALUES (%s, %s, %s, %s, %s)
                        ''', (nombre, descripcion, precio, stock, categoria_id))  
                        connection.commit()
                        flash('Producto agregado correctamente', 'success')
                        return redirect(url_for('inventario'))
                except ValueError:
                    flash('Precio y stock deben ser números válidos', 'error')
                except mysql.connector.Error as err:
                    connection.rollback()
                    flash(f'Error al agregar producto: {err}', 'error')

        return render_template('agregar_producto.html', categorias=categorias)

    except Exception as e:
        print(f"Error en agregar producto: {e}")
        flash('Ocurrió un error al cargar el formulario', 'error')
        return render_template('agregar_producto.html', categorias=[])
    finally:
        if 'cursor' in locals():
            cursor.close()
        if connection.is_connected():
            connection.close()
# --------------------- MAIN ---------------------
if __name__ == '__main__':
    app.run(debug=True)
